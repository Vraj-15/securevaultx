"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { HardDrive, Lock, Share2, Clock } from "lucide-react"
import { useAppStore, getStorageUsage } from "@/lib/store"
import { formatFileSize } from "@/lib/utils"
import { useEffect, useState } from "react"
import type { StorageUsage } from "@/lib/types"

export function StorageStats() {
  const { user, activities } = useAppStore()
  const [storageUsage, setStorageUsage] = useState<StorageUsage>({
    documents: 0,
    images: 0,
    archives: 0,
    other: 0,
  })

  useEffect(() => {
    setStorageUsage(getStorageUsage())
  }, [user])

  const storagePercentage = user ? Math.round((user.storageUsed / user.storageLimit) * 100) : 0

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Storage Usage</CardTitle>
          <CardDescription>
            {user ? `${formatFileSize(user.storageUsed)} of ${formatFileSize(user.storageLimit)} used` : "Loading..."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Progress value={storagePercentage} className="h-2" />
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">Documents</span>
              <div className="flex items-center mt-1">
                <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                <span className="text-sm font-medium">{formatFileSize(storageUsage.documents)}</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">Images</span>
              <div className="flex items-center mt-1">
                <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
                <span className="text-sm font-medium">{formatFileSize(storageUsage.images)}</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">Archives</span>
              <div className="flex items-center mt-1">
                <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></div>
                <span className="text-sm font-medium">{formatFileSize(storageUsage.archives)}</span>
              </div>
            </div>
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">Other</span>
              <div className="flex items-center mt-1">
                <div className="w-3 h-3 rounded-full bg-gray-500 mr-2"></div>
                <span className="text-sm font-medium">{formatFileSize(storageUsage.other)}</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Security Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                  <Lock className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">End-to-end encryption</p>
                  <p className="text-xs text-muted-foreground">All files are encrypted</p>
                </div>
              </div>
              <div className="h-2.5 w-2.5 rounded-full bg-green-500"></div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                  <HardDrive className="h-4 w-4 text-green-600" />
                </div>
                <div>
                  <p className="text-sm font-medium">Redundant storage</p>
                  <p className="text-xs text-muted-foreground">Multiple backups</p>
                </div>
              </div>
              <div className="h-2.5 w-2.5 rounded-full bg-green-500"></div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activities.slice(0, 3).map((activity) => (
              <div key={activity.id} className="flex items-start">
                <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center mr-3 mt-0.5">
                  {activity.type === "upload" && <Clock className="h-4 w-4 text-blue-600" />}
                  {activity.type === "share" && <Share2 className="h-4 w-4 text-purple-600" />}
                  {activity.type === "download" && <HardDrive className="h-4 w-4 text-green-600" />}
                  {activity.type === "delete" && <HardDrive className="h-4 w-4 text-red-600" />}
                </div>
                <div>
                  <p className="text-sm font-medium">
                    {activity.type === "upload" && `${activity.fileName} uploaded`}
                    {activity.type === "share" && `${activity.fileName} shared`}
                    {activity.type === "download" && `${activity.fileName} downloaded`}
                    {activity.type === "delete" && `${activity.fileName} deleted`}
                  </p>
                  <p className="text-xs text-muted-foreground">{new Date(activity.timestamp).toLocaleString()}</p>
                </div>
              </div>
            ))}

            {activities.length === 0 && (
              <div className="text-center py-2">
                <p className="text-sm text-muted-foreground">No recent activity</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

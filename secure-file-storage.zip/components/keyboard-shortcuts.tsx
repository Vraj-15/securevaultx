"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Keyboard } from "lucide-react"

interface ShortcutItem {
  keys: string[]
  description: string
}

const shortcuts: ShortcutItem[] = [
  { keys: ["Ctrl", "F"], description: "Search files" },
  { keys: ["Ctrl", "N"], description: "New folder" },
  { keys: ["Ctrl", "U"], description: "Upload files" },
  { keys: ["Ctrl", "A"], description: "Select all files" },
  { keys: ["Delete"], description: "Move selected files to trash" },
  { keys: ["Ctrl", "S"], description: "Star/unstar selected file" },
  { keys: ["Esc"], description: "Clear selection" },
  { keys: ["Ctrl", "G"], description: "Toggle grid/list view" },
  { keys: ["Ctrl", "/"], description: "Show keyboard shortcuts" },
  { keys: ["Ctrl", "D"], description: "Download selected files" },
]

export function KeyboardShortcuts() {
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + / to show shortcuts
      if (e.ctrlKey && e.key === "/") {
        e.preventDefault()
        setIsOpen(true)
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setIsOpen(true)}>
        <Keyboard className="h-4 w-4 mr-2" />
        Keyboard Shortcuts
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Keyboard Shortcuts</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid gap-2">
              {shortcuts.map((shortcut, index) => (
                <div key={index} className="flex items-center justify-between py-1">
                  <span className="text-sm">{shortcut.description}</span>
                  <div className="flex items-center gap-1">
                    {shortcut.keys.map((key, keyIndex) => (
                      <span key={keyIndex} className="px-2 py-1 rounded bg-muted text-xs font-mono font-medium">
                        {key}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}

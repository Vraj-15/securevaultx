"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import {
  Grid,
  List,
  MoreHorizontal,
  Download,
  Trash2,
  Share2,
  Lock,
  Eye,
  FileText,
  FileImage,
  FileArchive,
  FileIcon as FilePdf,
  Star,
  FolderIcon,
  ArrowUpDown,
  ChevronRight,
  SortAsc,
  SortDesc,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { useAppStore, getFilteredFiles, getFilteredFolders, getBreadcrumbPath } from "@/lib/store"
import { formatFileSize } from "@/lib/utils"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { FilePreview } from "@/components/file-preview"
import type { FileItem, Folder } from "@/lib/types"

export function FileGrid() {
  const {
    viewMode,
    setViewMode,
    selectedFiles,
    toggleFileSelection,
    clearSelectedFiles,
    deleteFiles,
    navigateToFolder,
    currentFolderId,
    createFolder,
    toggleFileStar,
    sortBy,
    sortDirection,
    setSortBy,
    setSortDirection,
    createShareLink,
  } = useAppStore()

  const [filteredFiles, setFilteredFiles] = useState<FileItem[]>([])
  const [filteredFolders, setFilteredFolders] = useState<Folder[]>([])
  const [breadcrumbs, setBreadcrumbs] = useState<Folder[]>([])
  const [activeTab, setActiveTab] = useState("all")
  const [isCreateFolderOpen, setIsCreateFolderOpen] = useState(false)
  const [newFolderName, setNewFolderName] = useState("")
  const [isShareDialogOpen, setIsShareDialogOpen] = useState(false)
  const [sharePassword, setSharePassword] = useState("")
  const [shareLink, setShareLink] = useState("")
  const [fileToShare, setFileToShare] = useState<string | null>(null)
  const [fileToPreview, setFileToPreview] = useState<string | null>(null)

  // Update filtered files and folders when store changes
  useEffect(() => {
    setFilteredFiles(getFilteredFiles())
    setFilteredFolders(getFilteredFolders())
    setBreadcrumbs(getBreadcrumbPath())
  }, [currentFolderId, sortBy, sortDirection])

  const handleTabChange = (value: string) => {
    setActiveTab(value)
    // In a real app, you would filter files based on the tab
  }

  const handleCreateFolder = () => {
    if (newFolderName.trim()) {
      createFolder(newFolderName.trim(), currentFolderId)
      setNewFolderName("")
      setIsCreateFolderOpen(false)
      // Refresh folders
      setFilteredFolders(getFilteredFolders())
    }
  }

  const handleShare = (fileId: string) => {
    setFileToShare(fileId)
    setIsShareDialogOpen(true)
  }

  const handlePreview = (fileId: string) => {
    setFileToPreview(fileId)
  }

  const handleCreateShareLink = () => {
    if (fileToShare) {
      const link = createShareLink(
        fileToShare,
        sharePassword.trim() || null,
        null, // No expiration for demo
      )
      setShareLink(link.url)
      setFileToShare(null)
      setSharePassword("")
    }
  }

  const handleSortChange = (newSortBy: "name" | "date" | "size") => {
    if (sortBy === newSortBy) {
      // Toggle direction if clicking the same sort option
      setSortDirection(sortDirection === "asc" ? "desc" : "asc")
    } else {
      setSortBy(newSortBy)
      setSortDirection("asc")
    }
  }

  const getFileIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FilePdf className="h-8 w-8 text-red-500" />
      case "doc":
      case "text":
        return <FileText className="h-8 w-8 text-blue-500" />
      case "image":
        return <FileImage className="h-8 w-8 text-purple-500" />
      case "archive":
        return <FileArchive className="h-8 w-8 text-yellow-500" />
      case "presentation":
        return <FileText className="h-8 w-8 text-orange-500" />
      case "spreadsheet":
        return <FileText className="h-8 w-8 text-green-500" />
      default:
        return <FileText className="h-8 w-8 text-gray-500" />
    }
  }

  return (
    <Card className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div className="flex flex-col">
          <h2 className="text-xl font-semibold">Your Files</h2>
          {breadcrumbs.length > 0 && (
            <div className="flex items-center text-sm text-muted-foreground mt-1">
              <Button variant="ghost" size="sm" className="h-6 px-2" onClick={() => navigateToFolder(null)}>
                Home
              </Button>
              {breadcrumbs.map((folder, index) => (
                <div key={folder.id} className="flex items-center">
                  <ChevronRight className="h-4 w-4 mx-1" />
                  <Button variant="ghost" size="sm" className="h-6 px-2" onClick={() => navigateToFolder(folder.id)}>
                    {folder.name}
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full md:w-auto">
            <TabsList>
              <TabsTrigger value="all">All Files</TabsTrigger>
              <TabsTrigger value="recent">Recent</TabsTrigger>
              <TabsTrigger value="shared">Shared</TabsTrigger>
            </TabsList>
          </Tabs>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <ArrowUpDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => handleSortChange("name")}>
                Name
                {sortBy === "name" &&
                  (sortDirection === "asc" ? (
                    <SortAsc className="ml-2 h-4 w-4" />
                  ) : (
                    <SortDesc className="ml-2 h-4 w-4" />
                  ))}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleSortChange("date")}>
                Date
                {sortBy === "date" &&
                  (sortDirection === "asc" ? (
                    <SortAsc className="ml-2 h-4 w-4" />
                  ) : (
                    <SortDesc className="ml-2 h-4 w-4" />
                  ))}
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => handleSortChange("size")}>
                Size
                {sortBy === "size" &&
                  (sortDirection === "asc" ? (
                    <SortAsc className="ml-2 h-4 w-4" />
                  ) : (
                    <SortDesc className="ml-2 h-4 w-4" />
                  ))}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <div className="flex border rounded-md">
            <Button
              variant="ghost"
              size="icon"
              className={cn("rounded-r-none", viewMode === "grid" && "bg-muted")}
              onClick={() => setViewMode("grid")}
            >
              <Grid className="h-4 w-4" />
              <span className="sr-only">Grid view</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className={cn("rounded-l-none", viewMode === "list" && "bg-muted")}
              onClick={() => setViewMode("list")}
            >
              <List className="h-4 w-4" />
              <span className="sr-only">List view</span>
            </Button>
          </div>
          <Button variant="outline" size="sm" onClick={() => setIsCreateFolderOpen(true)}>
            <FolderIcon className="h-4 w-4 mr-2" />
            New Folder
          </Button>
        </div>
      </div>

      {selectedFiles.length > 0 && (
        <div className="flex items-center justify-between bg-muted p-2 rounded-md mb-4">
          <span className="text-sm font-medium">{selectedFiles.length} files selected</span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-1" /> Download
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                if (selectedFiles.length === 1) {
                  handleShare(selectedFiles[0])
                }
              }}
              disabled={selectedFiles.length !== 1}
            >
              <Share2 className="h-4 w-4 mr-1" /> Share
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => {
                deleteFiles(selectedFiles)
                clearSelectedFiles()
              }}
            >
              <Trash2 className="h-4 w-4 mr-1" /> Delete
            </Button>
          </div>
        </div>
      )}

      {/* Folders */}
      {filteredFolders.length > 0 && (
        <div className="mb-6">
          <h3 className="text-sm font-medium mb-3">Folders</h3>
          <div className={viewMode === "grid" ? "grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" : "space-y-2"}>
            {filteredFolders.map((folder) =>
              viewMode === "grid" ? (
                <div
                  key={folder.id}
                  className="border rounded-lg p-4 cursor-pointer transition-all hover:border-primary/50 hover:shadow-sm"
                  onClick={() => navigateToFolder(folder.id)}
                >
                  <div className="flex flex-col items-center text-center">
                    <div className="mb-2">
                      <FolderIcon className="h-10 w-10 text-yellow-500" />
                    </div>
                    <div className="w-full">
                      <p className="font-medium text-sm truncate">{folder.name}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div
                  key={folder.id}
                  className="border rounded-lg p-3 cursor-pointer transition-all hover:border-primary/50 hover:shadow-sm"
                  onClick={() => navigateToFolder(folder.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <FolderIcon className="h-8 w-8 text-yellow-500" />
                      <div>
                        <p className="font-medium">{folder.name}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ),
            )}
          </div>
        </div>
      )}

      {/* Files */}
      {filteredFiles.length > 0 ? (
        viewMode === "grid" ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredFiles.map((file) => (
              <div
                key={file.id}
                className={cn(
                  "border rounded-lg p-4 cursor-pointer transition-all hover:border-primary/50 hover:shadow-sm",
                  selectedFiles.includes(file.id) && "border-primary bg-primary/5",
                )}
                onClick={() => toggleFileSelection(file.id)}
              >
                <div className="flex flex-col items-center text-center">
                  <div className="mb-2 relative">
                    {getFileIcon(file.type)}
                    {file.encrypted && (
                      <div className="absolute -top-1 -right-1 bg-green-100 rounded-full p-0.5">
                        <Lock className="h-3 w-3 text-green-600" />
                      </div>
                    )}
                  </div>
                  <div className="w-full">
                    <p className="font-medium text-sm truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                  </div>
                  <div className="mt-2 flex justify-between items-center w-full">
                    <span className="text-xs text-muted-foreground">
                      {new Date(file.modified).toLocaleDateString()}
                    </span>
                    <div className="flex">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={(e) => {
                          e.stopPropagation()
                          toggleFileStar(file.id)
                        }}
                      >
                        <Star
                          className={cn(
                            "h-4 w-4",
                            file.starred ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground",
                          )}
                        />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">More options</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation()
                              handlePreview(file.id)
                            }}
                          >
                            <Eye className="h-4 w-4 mr-2" /> Preview
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="h-4 w-4 mr-2" /> Download
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation()
                              handleShare(file.id)
                            }}
                          >
                            <Share2 className="h-4 w-4 mr-2" /> Share
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={(e) => {
                              e.stopPropagation()
                              deleteFiles([file.id])
                            }}
                          >
                            <Trash2 className="h-4 w-4 mr-2" /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {filteredFiles.map((file) => (
              <div
                key={file.id}
                className={cn(
                  "border rounded-lg p-3 cursor-pointer transition-all hover:border-primary/50 hover:shadow-sm",
                  selectedFiles.includes(file.id) && "border-primary bg-primary/5",
                )}
                onClick={() => toggleFileSelection(file.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      {getFileIcon(file.type)}
                      {file.encrypted && (
                        <div className="absolute -top-1 -right-1 bg-green-100 rounded-full p-0.5">
                          <Lock className="h-3 w-3 text-green-600" />
                        </div>
                      )}
                    </div>
                    <div>
                      <p className="font-medium">{file.name}</p>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <span>{formatFileSize(file.size)}</span>
                        <span className="mx-2">•</span>
                        <span>Modified {new Date(file.modified).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation()
                        toggleFileStar(file.id)
                      }}
                    >
                      <Star
                        className={cn(
                          "h-4 w-4",
                          file.starred ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground",
                        )}
                      />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation()
                        handlePreview(file.id)
                      }}
                    >
                      <Eye className="h-4 w-4" />
                      <span className="sr-only">Preview</span>
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={(e) => e.stopPropagation()}>
                      <Download className="h-4 w-4" />
                      <span className="sr-only">Download</span>
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={(e) => {
                        e.stopPropagation()
                        handleShare(file.id)
                      }}
                    >
                      <Share2 className="h-4 w-4" />
                      <span className="sr-only">Share</span>
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">More options</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={(e) => {
                            e.stopPropagation()
                            handlePreview(file.id)
                          }}
                        >
                          <Eye className="h-4 w-4 mr-2" /> Preview
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Download className="h-4 w-4 mr-2" /> Download
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          className="text-destructive"
                          onClick={(e) => {
                            e.stopPropagation()
                            deleteFiles([file.id])
                          }}
                        >
                          <Trash2 className="h-4 w-4 mr-2" /> Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      ) : (
        <div className="text-center py-12">
          <div className="flex justify-center mb-4">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
              <FileText className="h-6 w-6 text-muted-foreground" />
            </div>
          </div>
          <h3 className="text-lg font-medium">No files found</h3>
          <p className="text-sm text-muted-foreground mt-1">
            {currentFolderId ? "This folder is empty" : "Upload files to get started"}
          </p>
        </div>
      )}

      {/* Create Folder Dialog */}
      <Dialog open={isCreateFolderOpen} onOpenChange={setIsCreateFolderOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Folder</DialogTitle>
            <DialogDescription>Enter a name for your new folder</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Folder Name</Label>
              <Input
                id="name"
                placeholder="My Folder"
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleCreateFolder()
                  }
                }}
              />
            </div>
            <div className="flex justify-end">
              <Button onClick={handleCreateFolder}>Create Folder</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Share Dialog */}
      <Dialog open={isShareDialogOpen} onOpenChange={setIsShareDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Share File</DialogTitle>
            <DialogDescription>Create a secure link to share your file</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            {!shareLink ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="password">Password (Optional)</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter a password to protect your file"
                    value={sharePassword}
                    onChange={(e) => setSharePassword(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Leave blank for no password protection</p>
                </div>
                <div className="flex justify-end">
                  <Button onClick={handleCreateShareLink}>Create Share Link</Button>
                </div>
              </>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="link">Share Link</Label>
                  <div className="flex">
                    <Input id="link" value={shareLink} readOnly className="rounded-r-none" />
                    <Button
                      className="rounded-l-none"
                      onClick={() => {
                        navigator.clipboard.writeText(shareLink)
                      }}
                    >
                      Copy
                    </Button>
                  </div>
                  {sharePassword && (
                    <p className="text-sm mt-2">
                      Password: <span className="font-medium">{sharePassword}</span>
                    </p>
                  )}
                </div>
                <div className="flex justify-end">
                  <Button
                    onClick={() => {
                      setShareLink("")
                      setIsShareDialogOpen(false)
                    }}
                  >
                    Done
                  </Button>
                </div>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* File Preview */}
      <FilePreview fileId={fileToPreview} onClose={() => setFileToPreview(null)} />
    </Card>
  )
}

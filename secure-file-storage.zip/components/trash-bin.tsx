"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAppStore } from "@/lib/store"
import { formatFileSize, formatDate } from "@/lib/utils"
import { Trash2, MoreHorizontal, RefreshCw, FileText, FileImage, FileArchive, FileIcon as FilePdf } from "lucide-react"
import { cn } from "@/lib/utils"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import type { FileItem } from "@/lib/types"

export function TrashBin() {
  const { files, restoreFiles, deleteFilesPermanently } = useAppStore()
  const [deletedFiles, setDeletedFiles] = useState<FileItem[]>([])
  const [selectedFiles, setSelectedFiles] = useState<string[]>([])
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false)
  const [viewMode, setViewMode] = useState<"grid" | "list">("list")

  // In a real app, we would have a separate "deleted" flag or a trash collection
  // For this demo, we'll simulate deleted files with a special property
  useEffect(() => {
    // Simulate deleted files (in a real app, these would be in a separate collection)
    const deleted = files.filter((file) => file.name.includes("deleted"))
    setDeletedFiles(deleted)
  }, [files])

  const toggleFileSelection = (fileId: string) => {
    if (selectedFiles.includes(fileId)) {
      setSelectedFiles(selectedFiles.filter((id) => id !== fileId))
    } else {
      setSelectedFiles([...selectedFiles, fileId])
    }
  }

  const handleRestore = () => {
    if (selectedFiles.length > 0) {
      restoreFiles(selectedFiles)
      setSelectedFiles([])
    }
  }

  const handleDeletePermanently = () => {
    if (selectedFiles.length > 0) {
      deleteFilesPermanently(selectedFiles)
      setSelectedFiles([])
      setIsConfirmDialogOpen(false)
    }
  }

  const getFileIcon = (type: string) => {
    switch (type) {
      case "pdf":
        return <FilePdf className="h-8 w-8 text-red-500" />
      case "doc":
      case "text":
        return <FileText className="h-8 w-8 text-blue-500" />
      case "image":
        return <FileImage className="h-8 w-8 text-purple-500" />
      case "archive":
        return <FileArchive className="h-8 w-8 text-yellow-500" />
      default:
        return <FileText className="h-8 w-8 text-gray-500" />
    }
  }

  return (
    <Card className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Trash</h2>
        <div className="flex items-center gap-2">
          <Tabs defaultValue="all" className="w-[200px]">
            <TabsList>
              <TabsTrigger value="all">All Items</TabsTrigger>
              <TabsTrigger value="recent">Recent</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {selectedFiles.length > 0 && (
        <div className="flex items-center justify-between bg-muted p-2 rounded-md mb-4">
          <span className="text-sm font-medium">{selectedFiles.length} files selected</span>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleRestore}>
              <RefreshCw className="h-4 w-4 mr-1" /> Restore
            </Button>
            <Button variant="destructive" size="sm" onClick={() => setIsConfirmDialogOpen(true)}>
              <Trash2 className="h-4 w-4 mr-1" /> Delete Permanently
            </Button>
          </div>
        </div>
      )}

      {deletedFiles.length > 0 ? (
        <div className="space-y-2">
          {deletedFiles.map((file) => (
            <div
              key={file.id}
              className={cn(
                "border rounded-lg p-3 cursor-pointer transition-all hover:border-primary/50 hover:shadow-sm",
                selectedFiles.includes(file.id) && "border-primary bg-primary/5",
              )}
              onClick={() => toggleFileSelection(file.id)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="relative">{getFileIcon(file.type)}</div>
                  <div>
                    <p className="font-medium">{file.name}</p>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>{formatFileSize(file.size)}</span>
                      <span className="mx-2">•</span>
                      <span>Deleted {formatDate(file.modified)}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={(e) => {
                      e.stopPropagation()
                      handleRestore()
                    }}
                  >
                    <RefreshCw className="h-4 w-4" />
                    <span className="sr-only">Restore</span>
                  </Button>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">More options</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem
                        onClick={(e) => {
                          e.stopPropagation()
                          setSelectedFiles([file.id])
                          handleRestore()
                        }}
                      >
                        <RefreshCw className="h-4 w-4 mr-2" /> Restore
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive"
                        onClick={(e) => {
                          e.stopPropagation()
                          setSelectedFiles([file.id])
                          setIsConfirmDialogOpen(true)
                        }}
                      >
                        <Trash2 className="h-4 w-4 mr-2" /> Delete Permanently
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="flex justify-center mb-4">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
              <Trash2 className="h-6 w-6 text-muted-foreground" />
            </div>
          </div>
          <h3 className="text-lg font-medium">Trash is empty</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Items in trash will be automatically deleted after 30 days
          </p>
        </div>
      )}

      {/* Confirm Delete Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Permanently</DialogTitle>
          </DialogHeader>
          <p>
            Are you sure you want to permanently delete {selectedFiles.length}{" "}
            {selectedFiles.length === 1 ? "file" : "files"}? This action cannot be undone.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsConfirmDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeletePermanently}>
              Delete Permanently
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

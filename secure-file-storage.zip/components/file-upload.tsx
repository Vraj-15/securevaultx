"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Upload, X, FolderPlus } from "lucide-react"
import { cn } from "@/lib/utils"
import { useAppStore } from "@/lib/store"
import { formatFileSize } from "@/lib/utils"

export function FileUpload() {
  const [isDragging, setIsDragging] = useState(false)
  const [files, setFiles] = useState<File[]>([])
  const [uploadProgress, setUploadProgress] = useState<Record<string, number>>({})
  const [isUploading, setIsUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { uploadFiles, user } = useAppStore()

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = () => {
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    if (e.dataTransfer.files) {
      const newFiles = Array.from(e.dataTransfer.files)
      setFiles((prev) => [...prev, ...newFiles])
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setFiles((prev) => [...prev, ...newFiles])
    }
  }

  const removeFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index))
  }

  const handleUpload = async () => {
    if (files.length === 0) return

    setIsUploading(true)

    // Simulate file upload with progress
    files.forEach((file, index) => {
      let progress = 0
      const interval = setInterval(() => {
        progress += Math.random() * 10
        if (progress >= 100) {
          progress = 100
          clearInterval(interval)

          // Check if all files are uploaded
          const allUploaded = Object.values({
            ...uploadProgress,
            [file.name]: progress,
          }).every((p) => p === 100)

          if (allUploaded) {
            setTimeout(async () => {
              await uploadFiles(files)
              setIsUploading(false)
              setFiles([])
              setUploadProgress({})
            }, 500)
          }
        }

        setUploadProgress((prev) => ({
          ...prev,
          [file.name]: progress,
        }))
      }, 300)
    })
  }

  // Calculate total size of files to be uploaded
  const totalUploadSize = files.reduce((total, file) => total + file.size, 0)
  const isOverStorageLimit = user && user.storageUsed + totalUploadSize > user.storageLimit

  return (
    <div className="mb-6">
      <Card>
        <CardContent className="p-6">
          <div
            className={cn(
              "border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors",
              isDragging ? "border-primary bg-primary/5" : "border-muted-foreground/25 hover:border-primary/50",
              isUploading ? "pointer-events-none" : "",
              isOverStorageLimit ? "border-destructive/50" : "",
            )}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" multiple />
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Upload className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold">Upload files</h3>
              <p className="text-sm text-muted-foreground max-w-md">
                Drag and drop files here or click to browse. Your files will be encrypted and stored securely.
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-2"
                onClick={(e) => {
                  e.stopPropagation()
                  fileInputRef.current?.click()
                }}
              >
                <FolderPlus className="mr-2 h-4 w-4" />
                Browse files
              </Button>
            </div>
          </div>

          {isOverStorageLimit && (
            <div className="mt-2 text-sm text-destructive">
              Warning: You don't have enough storage space. Please free up some space before uploading.
            </div>
          )}

          {files.length > 0 && (
            <div className="mt-6 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium">Files to upload ({files.length})</h4>
                <Button variant="default" size="sm" onClick={handleUpload} disabled={isUploading || isOverStorageLimit}>
                  {isUploading ? (
                    <span className="flex items-center">
                      <span className="h-4 w-4 mr-2 rounded-full border-2 border-current border-r-transparent animate-spin" />
                      Uploading...
                    </span>
                  ) : (
                    <span className="flex items-center">
                      <Upload className="mr-2 h-4 w-4" /> Upload all
                    </span>
                  )}
                </Button>
              </div>

              <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-md">
                    <div className="flex items-center space-x-3 overflow-hidden">
                      <div className="flex-shrink-0 h-10 w-10 rounded bg-background flex items-center justify-center">
                        <FileTypeIcon fileName={file.name} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium truncate">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{formatFileSize(file.size)}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {uploadProgress[file.name] !== undefined && (
                        <div className="w-24">
                          <Progress value={uploadProgress[file.name]} className="h-2" />
                        </div>
                      )}

                      {!isUploading && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-muted-foreground hover:text-foreground"
                          onClick={(e) => {
                            e.stopPropagation()
                            removeFile(index)
                          }}
                        >
                          <X className="h-4 w-4" />
                          <span className="sr-only">Remove</span>
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

function FileTypeIcon({ fileName }: { fileName: string }) {
  const extension = fileName.split(".").pop()?.toLowerCase() || ""

  // You can expand this with more file type icons
  switch (extension) {
    case "pdf":
      return <div className="text-red-500 text-xs font-bold">PDF</div>
    case "doc":
    case "docx":
      return <div className="text-blue-500 text-xs font-bold">DOC</div>
    case "xls":
    case "xlsx":
      return <div className="text-green-500 text-xs font-bold">XLS</div>
    case "jpg":
    case "jpeg":
    case "png":
    case "gif":
      return <div className="text-purple-500 text-xs font-bold">IMG</div>
    default:
      return <div className="text-gray-500 text-xs font-bold">FILE</div>
  }
}

"use client"

import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search, X } from "lucide-react"
import { useAppStore } from "@/lib/store"

export function SearchBar() {
  const { searchQuery, setSearchQuery } = useAppStore()
  const [localSearchQuery, setLocalSearchQuery] = useState(searchQuery)

  // Sync local state with store
  useEffect(() => {
    setLocalSearchQuery(searchQuery)
  }, [searchQuery])

  const handleSearch = () => {
    setSearchQuery(localSearchQuery)
  }

  const handleClear = () => {
    setLocalSearchQuery("")
    setSearchQuery("")
  }

  return (
    <div className="relative w-full max-w-sm">
      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
      <Input
        type="search"
        placeholder="Search files..."
        className="pl-8 pr-10"
        value={localSearchQuery}
        onChange={(e) => setLocalSearchQuery(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            handleSearch()
          }
        }}
      />
      {localSearchQuery && (
        <Button variant="ghost" size="icon" className="absolute right-0 top-0 h-9 w-9" onClick={handleClear}>
          <X className="h-4 w-4" />
          <span className="sr-only">Clear search</span>
        </Button>
      )}
    </div>
  )
}

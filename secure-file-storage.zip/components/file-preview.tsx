"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useAppStore } from "@/lib/store"
import { formatFileSize, formatDate } from "@/lib/utils"
import { Download, X, Info, Lock, Calendar, User, Tag, Star, StarOff } from "lucide-react"
import Image from "next/image"
import type { FileItem } from "@/lib/types"

interface FilePreviewProps {
  fileId: string | null
  onClose: () => void
}

export function FilePreview({ fileId, onClose }: FilePreviewProps) {
  const { files, toggleFileStar } = useAppStore()
  const [file, setFile] = useState<FileItem | null>(null)
  const [activeTab, setActiveTab] = useState<"preview" | "details">("preview")

  useEffect(() => {
    if (fileId) {
      const foundFile = files.find((f) => f.id === fileId)
      setFile(foundFile || null)
    } else {
      setFile(null)
    }
  }, [fileId, files])

  if (!file) return null

  const isPreviewable = (type: string) => {
    return ["image", "pdf", "text"].includes(type)
  }

  const renderPreview = () => {
    if (!file) return null

    switch (file.type) {
      case "image":
        return (
          <div className="flex items-center justify-center h-[400px] bg-muted/30 rounded-lg">
            <Image
              src={`/placeholder.svg?height=400&width=600&text=${encodeURIComponent(file.name)}`}
              alt={file.name}
              width={600}
              height={400}
              className="max-h-full max-w-full object-contain"
            />
          </div>
        )
      case "pdf":
        return (
          <div className="flex flex-col items-center justify-center h-[400px] bg-muted/30 rounded-lg p-4">
            <div className="w-20 h-24 bg-red-100 rounded-lg flex items-center justify-center mb-4">
              <span className="text-red-600 font-bold">PDF</span>
            </div>
            <p className="text-center text-muted-foreground">PDF preview is not available in this demo</p>
          </div>
        )
      case "text":
        return (
          <div className="h-[400px] bg-muted/30 rounded-lg p-4 overflow-auto">
            <pre className="text-sm whitespace-pre-wrap">
              {`This is a simulated preview of the text file "${file.name}".

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, quis aliquam nisl nunc eu nisl. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, quis aliquam nisl nunc eu nisl.

Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, quis aliquam nisl nunc eu nisl. Nullam euismod, nisl eget aliquam ultricies, nunc nisl aliquet nunc, quis aliquam nisl nunc eu nisl.`}
            </pre>
          </div>
        )
      default:
        return (
          <div className="flex flex-col items-center justify-center h-[400px] bg-muted/30 rounded-lg">
            <div className="w-20 h-24 bg-gray-100 rounded-lg flex items-center justify-center mb-4">
              <span className="text-gray-600 font-bold">{file.type.toUpperCase()}</span>
            </div>
            <p className="text-center text-muted-foreground">Preview not available for this file type</p>
          </div>
        )
    }
  }

  return (
    <Dialog open={!!fileId} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="truncate pr-4">{file.name}</DialogTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => toggleFileStar(file.id)}
                title={file.starred ? "Remove from starred" : "Add to starred"}
              >
                {file.starred ? (
                  <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ) : (
                  <StarOff className="h-4 w-4" />
                )}
              </Button>
              <Button variant="ghost" size="icon" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <DialogDescription>
            {formatFileSize(file.size)} • Modified {formatDate(file.modified)}
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="preview" value={activeTab} onValueChange={(value) => setActiveTab(value as any)}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="preview" disabled={!isPreviewable(file.type)}>
              Preview
            </TabsTrigger>
            <TabsTrigger value="details">Details</TabsTrigger>
          </TabsList>
          <TabsContent value="preview" className="mt-4">
            {renderPreview()}
          </TabsContent>
          <TabsContent value="details" className="mt-4">
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium flex items-center">
                    <Info className="h-4 w-4 mr-2" /> File Type
                  </p>
                  <p className="text-sm text-muted-foreground">{file.type.toUpperCase()}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium flex items-center">
                    <Lock className="h-4 w-4 mr-2" /> Encryption
                  </p>
                  <p className="text-sm text-muted-foreground">{file.encrypted ? "Encrypted" : "Not encrypted"}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-2" /> Created
                  </p>
                  <p className="text-sm text-muted-foreground">{formatDate(file.modified)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-2" /> Modified
                  </p>
                  <p className="text-sm text-muted-foreground">{formatDate(file.modified)}</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium flex items-center">
                    <User className="h-4 w-4 mr-2" /> Owner
                  </p>
                  <p className="text-sm text-muted-foreground">You</p>
                </div>
                <div className="space-y-1">
                  <p className="text-sm font-medium flex items-center">
                    <Tag className="h-4 w-4 mr-2" /> Tags
                  </p>
                  <p className="text-sm text-muted-foreground">None</p>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button className="w-full">
                  <Download className="h-4 w-4 mr-2" /> Download
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

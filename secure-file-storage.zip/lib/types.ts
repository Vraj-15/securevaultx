export interface User {
  id: string
  name: string
  email: string
  avatar?: string
  storageLimit: number
  storageUsed: number
}

export interface FileItem {
  id: string
  name: string
  size: number
  type: string
  modified: string
  encrypted: boolean
  starred: boolean
  folderId: string | null
  createdBy: string
  tags: string[]
}

export interface Folder {
  id: string
  name: string
  parentId: string | null
  createdAt: string
  createdBy: string
}

export interface StorageUsage {
  documents: number
  images: number
  archives: number
  other: number
}

export interface Activity {
  id: string
  type: "upload" | "download" | "share" | "delete"
  fileName: string
  timestamp: string
  userId: string
}

export interface ShareLink {
  id: string
  fileId: string
  url: string
  expiresAt: string | null
  password: string | null
  createdAt: string
}

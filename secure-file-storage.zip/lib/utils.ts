import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes"
  const k = 1024
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"]
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i]
}

export function formatDate(date: string): string {
  const d = new Date(date)
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
  })
}

export function getFileTypeFromName(fileName: string): string {
  const extension = fileName.split(".").pop()?.toLowerCase() || ""

  if (["pdf"].includes(extension)) {
    return "pdf"
  } else if (["doc", "docx", "txt", "rtf"].includes(extension)) {
    return "doc"
  } else if (["xls", "xlsx", "csv"].includes(extension)) {
    return "spreadsheet"
  } else if (["ppt", "pptx"].includes(extension)) {
    return "presentation"
  } else if (["jpg", "jpeg", "png", "gif", "bmp", "svg", "webp"].includes(extension)) {
    return "image"
  } else if (["zip", "rar", "7z", "tar", "gz"].includes(extension)) {
    return "archive"
  } else {
    return "unknown"
  }
}

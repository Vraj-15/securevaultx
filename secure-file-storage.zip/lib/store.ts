"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import { v4 as uuidv4 } from "uuid"
import type { User, FileItem, Folder, Activity, ShareLink, StorageUsage } from "./types"

interface AppState {
  // Auth
  user: User | null
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<boolean>
  signup: (name: string, email: string, password: string) => Promise<boolean>
  logout: () => void

  // Files
  files: FileItem[]
  folders: Folder[]
  currentFolderId: string | null
  searchQuery: string
  selectedFiles: string[]
  viewMode: "grid" | "list"
  sortBy: "name" | "date" | "size"
  sortDirection: "asc" | "desc"

  // Actions
  uploadFiles: (files: File[]) => Promise<void>
  deleteFiles: (fileIds: string[]) => void
  createFolder: (name: string, parentId: string | null) => void
  renameFile: (fileId: string, newName: string) => void
  renameFolder: (folderId: string, newName: string) => void
  moveFiles: (fileIds: string[], targetFolderId: string | null) => void
  navigateToFolder: (folderId: string | null) => void
  toggleFileSelection: (fileId: string) => void
  clearSelectedFiles: () => void
  setSearchQuery: (query: string) => void
  setViewMode: (mode: "grid" | "list") => void
  setSortBy: (sortBy: "name" | "date" | "size") => void
  setSortDirection: (direction: "asc" | "desc") => void
  toggleFileStar: (fileId: string) => void

  // New functionality
  restoreFiles: (fileIds: string[]) => void
  deleteFilesPermanently: (fileIds: string[]) => void
  addTag: (fileId: string, tag: string) => void
  removeTag: (fileId: string, tag: string) => void

  // Activities
  activities: Activity[]
  addActivity: (activity: Omit<Activity, "id" | "timestamp" | "userId">) => void

  // Sharing
  shareLinks: ShareLink[]
  createShareLink: (fileId: string, password: string | null, expiresAt: string | null) => ShareLink
  deleteShareLink: (linkId: string) => void
}

// Mock data
const mockUser: User = {
  id: "1",
  name: "Demo User",
  email: "demo@example.com",
  avatar: "",
  storageLimit: 10 * 1024 * 1024 * 1024, // 10GB
  storageUsed: 7.2 * 1024 * 1024 * 1024, // 7.2GB
}

const generateMockFiles = (): FileItem[] => {
  return [
    {
      id: "1",
      name: "Financial Report Q1.pdf",
      size: 2.4 * 1024 * 1024,
      type: "pdf",
      modified: new Date().toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: [],
    },
    {
      id: "2",
      name: "Project Proposal.docx",
      size: 1.8 * 1024 * 1024,
      type: "doc",
      modified: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: true,
      folderId: null,
      createdBy: "1",
      tags: ["work", "important"],
    },
    {
      id: "3",
      name: "Company Logo.png",
      size: 0.5 * 1024 * 1024,
      type: "image",
      modified: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: ["design"],
    },
    {
      id: "4",
      name: "Client Meeting Notes.txt",
      size: 0.1 * 1024 * 1024,
      type: "text",
      modified: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: ["work", "meeting"],
    },
    {
      id: "5",
      name: "Product Designs.zip",
      size: 15.2 * 1024 * 1024,
      type: "archive",
      modified: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: ["design", "product"],
    },
    {
      id: "6",
      name: "Marketing Strategy.pptx",
      size: 4.7 * 1024 * 1024,
      type: "presentation",
      modified: new Date(Date.now() - 21 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: ["marketing"],
    },
    {
      id: "7",
      name: "Budget 2023.xlsx",
      size: 1.2 * 1024 * 1024,
      type: "spreadsheet",
      modified: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: true,
      folderId: null,
      createdBy: "1",
      tags: ["finance"],
    },
    {
      id: "8",
      name: "Team Photo.jpg",
      size: 3.5 * 1024 * 1024,
      type: "image",
      modified: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: ["team"],
    },
    // Add some "deleted" files for the trash bin demo
    {
      id: "9",
      name: "deleted-Old Report.pdf",
      size: 1.7 * 1024 * 1024,
      type: "pdf",
      modified: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: [],
    },
    {
      id: "10",
      name: "deleted-Outdated Logo.png",
      size: 0.8 * 1024 * 1024,
      type: "image",
      modified: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
      encrypted: true,
      starred: false,
      folderId: null,
      createdBy: "1",
      tags: [],
    },
  ]
}

const generateMockFolders = (): Folder[] => {
  return [
    {
      id: "f1",
      name: "Documents",
      parentId: null,
      createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000).toISOString(),
      createdBy: "1",
    },
    {
      id: "f2",
      name: "Images",
      parentId: null,
      createdAt: new Date(Date.now() - 55 * 24 * 60 * 60 * 1000).toISOString(),
      createdBy: "1",
    },
    {
      id: "f3",
      name: "Projects",
      parentId: null,
      createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
      createdBy: "1",
    },
    {
      id: "f4",
      name: "Reports",
      parentId: "f1",
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      createdBy: "1",
    },
  ]
}

const generateMockActivities = (): Activity[] => {
  return [
    {
      id: "a1",
      type: "upload",
      fileName: "Financial Report Q1.pdf",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      userId: "1",
    },
    {
      id: "a2",
      type: "share",
      fileName: "Project Proposal.docx",
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
      userId: "1",
    },
    {
      id: "a3",
      type: "download",
      fileName: "Budget 2023.xlsx",
      timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
      userId: "1",
    },
  ]
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Auth
      user: null,
      isAuthenticated: false,
      login: async (email, password) => {
        // Simulate API call with a consistent timing
        await new Promise((resolve) => setTimeout(resolve, 800))

        // Simple validation
        if (email === "demo@example.com" && password === "password") {
          // Set authenticated first, then user data to prevent UI jumps
          set({ isAuthenticated: true })
          // Small delay before setting user data
          await new Promise((resolve) => setTimeout(resolve, 50))
          set({ user: mockUser })
          return true
        }
        return false
      },
      signup: async (name, email, password) => {
        // Simulate API call
        await new Promise((resolve) => setTimeout(resolve, 1000))

        const newUser: User = {
          id: uuidv4(),
          name,
          email,
          storageLimit: 10 * 1024 * 1024 * 1024, // 10GB
          storageUsed: 0,
        }

        set({ user: newUser, isAuthenticated: true })
        return true
      },
      logout: () => {
        set({ user: null, isAuthenticated: false })
      },

      // Files
      files: generateMockFiles(),
      folders: generateMockFolders(),
      currentFolderId: null,
      searchQuery: "",
      selectedFiles: [],
      viewMode: "grid",
      sortBy: "date",
      sortDirection: "desc",

      // Actions
      uploadFiles: async (files: File[]) => {
        // Simulate upload delay
        await new Promise((resolve) => setTimeout(resolve, 1500))

        const newFiles: FileItem[] = Array.from(files).map((file) => ({
          id: uuidv4(),
          name: file.name,
          size: file.size,
          type: file.name.split(".").pop() || "unknown",
          modified: new Date().toISOString(),
          encrypted: true,
          starred: false,
          folderId: get().currentFolderId,
          createdBy: get().user?.id || "1",
          tags: [],
        }))

        // Update storage used
        const additionalStorage = newFiles.reduce((total, file) => total + file.size, 0)
        const user = get().user

        if (user) {
          set({
            files: [...get().files, ...newFiles],
            user: {
              ...user,
              storageUsed: user.storageUsed + additionalStorage,
            },
          })
        } else {
          set({ files: [...get().files, ...newFiles] })
        }

        // Add activity
        newFiles.forEach((file) => {
          get().addActivity({ type: "upload", fileName: file.name })
        })
      },
      deleteFiles: (fileIds: string[]) => {
        const filesToDelete = get().files.filter((file) => fileIds.includes(file.id))

        // In a real app, we would move these to trash
        // For this demo, we'll just rename them to indicate they're deleted
        const updatedFiles = get().files.map((file) => {
          if (fileIds.includes(file.id)) {
            return {
              ...file,
              name: `deleted-${file.name}`,
            }
          }
          return file
        })

        // Update storage used (in a real app, we wouldn't reduce storage for trashed files)
        const user = get().user

        set({
          files: updatedFiles,
          selectedFiles: get().selectedFiles.filter((id) => !fileIds.includes(id)),
        })

        // Add activity
        filesToDelete.forEach((file) => {
          get().addActivity({ type: "delete", fileName: file.name })
        })
      },

      // New functionality
      restoreFiles: (fileIds: string[]) => {
        // Restore files from trash by removing the "deleted-" prefix
        const updatedFiles = get().files.map((file) => {
          if (fileIds.includes(file.id) && file.name.startsWith("deleted-")) {
            return {
              ...file,
              name: file.name.replace("deleted-", ""),
            }
          }
          return file
        })

        set({
          files: updatedFiles,
          selectedFiles: get().selectedFiles.filter((id) => !fileIds.includes(id)),
        })

        // Add activity
        fileIds.forEach((fileId) => {
          const file = get().files.find((f) => f.id === fileId)
          if (file) {
            get().addActivity({
              type: "upload",
              fileName: file.name.replace("deleted-", ""),
            })
          }
        })
      },

      deleteFilesPermanently: (fileIds: string[]) => {
        const filesToDelete = get().files.filter((file) => fileIds.includes(file.id))
        const remainingFiles = get().files.filter((file) => !fileIds.includes(file.id))

        // Update storage used
        const freedStorage = filesToDelete.reduce((total, file) => total + file.size, 0)
        const user = get().user

        if (user) {
          set({
            files: remainingFiles,
            selectedFiles: get().selectedFiles.filter((id) => !fileIds.includes(id)),
            user: {
              ...user,
              storageUsed: Math.max(0, user.storageUsed - freedStorage),
            },
          })
        } else {
          set({
            files: remainingFiles,
            selectedFiles: get().selectedFiles.filter((id) => !fileIds.includes(id)),
          })
        }

        // Add activity
        filesToDelete.forEach((file) => {
          get().addActivity({
            type: "delete",
            fileName: file.name.replace("deleted-", ""),
          })
        })
      },

      addTag: (fileId: string, tag: string) => {
        const updatedFiles = get().files.map((file) => {
          if (file.id === fileId && !file.tags.includes(tag)) {
            return {
              ...file,
              tags: [...file.tags, tag],
            }
          }
          return file
        })

        set({ files: updatedFiles })
      },

      removeTag: (fileId: string, tag: string) => {
        const updatedFiles = get().files.map((file) => {
          if (file.id === fileId) {
            return {
              ...file,
              tags: file.tags.filter((t) => t !== tag),
            }
          }
          return file
        })

        set({ files: updatedFiles })
      },

      createFolder: (name: string, parentId: string | null) => {
        const newFolder: Folder = {
          id: uuidv4(),
          name,
          parentId,
          createdAt: new Date().toISOString(),
          createdBy: get().user?.id || "1",
        }

        set({ folders: [...get().folders, newFolder] })
      },
      renameFile: (fileId: string, newName: string) => {
        const updatedFiles = get().files.map((file) => (file.id === fileId ? { ...file, name: newName } : file))

        set({ files: updatedFiles })
      },
      renameFolder: (folderId: string, newName: string) => {
        const updatedFolders = get().folders.map((folder) =>
          folder.id === folderId ? { ...folder, name: newName } : folder,
        )

        set({ folders: updatedFolders })
      },
      moveFiles: (fileIds: string[], targetFolderId: string | null) => {
        const updatedFiles = get().files.map((file) =>
          fileIds.includes(file.id) ? { ...file, folderId: targetFolderId } : file,
        )

        set({ files: updatedFiles })
      },
      navigateToFolder: (folderId: string | null) => {
        set({ currentFolderId: folderId, selectedFiles: [] })
      },
      toggleFileSelection: (fileId: string) => {
        const selectedFiles = get().selectedFiles

        if (selectedFiles.includes(fileId)) {
          set({ selectedFiles: selectedFiles.filter((id) => id !== fileId) })
        } else {
          set({ selectedFiles: [...selectedFiles, fileId] })
        }
      },
      clearSelectedFiles: () => {
        set({ selectedFiles: [] })
      },
      setSearchQuery: (query: string) => {
        set({ searchQuery: query })
      },
      setViewMode: (mode: "grid" | "list") => {
        set({ viewMode: mode })
      },
      setSortBy: (sortBy: "name" | "date" | "size") => {
        set({ sortBy })
      },
      setSortDirection: (direction: "asc" | "desc") => {
        set({ sortDirection: direction })
      },
      toggleFileStar: (fileId: string) => {
        const updatedFiles = get().files.map((file) =>
          file.id === fileId ? { ...file, starred: !file.starred } : file,
        )

        set({ files: updatedFiles })
      },

      // Activities
      activities: generateMockActivities(),
      addActivity: (activity) => {
        const newActivity: Activity = {
          id: uuidv4(),
          ...activity,
          timestamp: new Date().toISOString(),
          userId: get().user?.id || "1",
        }

        set({ activities: [newActivity, ...get().activities] })
      },

      // Sharing
      shareLinks: [],
      createShareLink: (fileId, password, expiresAt) => {
        const newLink: ShareLink = {
          id: uuidv4(),
          fileId,
          url: `https://securefile.example/share/${uuidv4()}`,
          expiresAt,
          password,
          createdAt: new Date().toISOString(),
        }

        set({ shareLinks: [...get().shareLinks, newLink] })

        // Add activity
        const file = get().files.find((f) => f.id === fileId)
        if (file) {
          get().addActivity({ type: "share", fileName: file.name })
        }

        return newLink
      },
      deleteShareLink: (linkId) => {
        set({ shareLinks: get().shareLinks.filter((link) => link.id !== linkId) })
      },
    }),
    {
      name: "secure-storage-state",
    },
  ),
)

// Helper functions to get derived state
export const getFilteredFiles = () => {
  const { files, folders, currentFolderId, searchQuery, sortBy, sortDirection } = useAppStore.getState()

  // Filter out deleted files (those with "deleted-" prefix)
  let filteredFiles = files.filter((file) => file.folderId === currentFolderId && !file.name.startsWith("deleted-"))

  if (searchQuery) {
    const query = searchQuery.toLowerCase()
    filteredFiles = files.filter((file) => !file.name.startsWith("deleted-") && file.name.toLowerCase().includes(query))
  }

  // Sort files
  return filteredFiles.sort((a, b) => {
    if (sortBy === "name") {
      return sortDirection === "asc" ? a.name.localeCompare(b.name) : b.name.localeCompare(a.name)
    } else if (sortBy === "date") {
      return sortDirection === "asc"
        ? new Date(a.modified).getTime() - new Date(b.modified).getTime()
        : new Date(b.modified).getTime() - new Date(a.modified).getTime()
    } else if (sortBy === "size") {
      return sortDirection === "asc" ? a.size - b.size : b.size - a.size
    }
    return 0
  })
}

export const getFilteredFolders = () => {
  const { folders, currentFolderId, searchQuery } = useAppStore.getState()

  let filteredFolders = folders.filter((folder) => folder.parentId === currentFolderId)

  if (searchQuery) {
    const query = searchQuery.toLowerCase()
    filteredFolders = folders.filter((folder) => folder.name.toLowerCase().includes(query))
  }

  return filteredFolders.sort((a, b) => a.name.localeCompare(b.name))
}

export const getBreadcrumbPath = () => {
  const { folders, currentFolderId } = useAppStore.getState()

  const path: Folder[] = []
  let currentFolder = folders.find((f) => f.id === currentFolderId)

  while (currentFolder) {
    path.unshift(currentFolder)
    currentFolder = folders.find((f) => f.id === currentFolder?.parentId)
  }

  return path
}

export const getStorageUsage = (): StorageUsage => {
  const { files } = useAppStore.getState()

  const usage: StorageUsage = {
    documents: 0,
    images: 0,
    archives: 0,
    other: 0,
  }

  files.forEach((file) => {
    // Skip deleted files
    if (file.name.startsWith("deleted-")) return

    const type = file.type.toLowerCase()
    if (["pdf", "doc", "docx", "txt", "rtf", "ppt", "pptx", "xls", "xlsx"].includes(type)) {
      usage.documents += file.size
    } else if (["jpg", "jpeg", "png", "gif", "bmp", "svg", "webp"].includes(type)) {
      usage.images += file.size
    } else if (["zip", "rar", "7z", "tar", "gz"].includes(type)) {
      usage.archives += file.size
    } else {
      usage.other += file.size
    }
  })

  return usage
}

export const getStarredFiles = () => {
  const { files } = useAppStore.getState()
  return files.filter((file) => file.starred && !file.name.startsWith("deleted-"))
}

export const getRecentFiles = () => {
  const { files } = useAppStore.getState()

  // Get files that aren't deleted and sort by modified date
  return files
    .filter((file) => !file.name.startsWith("deleted-"))
    .sort((a, b) => new Date(b.modified).getTime() - new Date(a.modified).getTime())
    .slice(0, 10) // Get the 10 most recent files
}

export const getDeletedFiles = () => {
  const { files } = useAppStore.getState()
  return files.filter((file) => file.name.startsWith("deleted-"))
}

"use client"

import { useEffect, useState } from "react"
import { redirect } from "next/navigation"
import { SearchBar } from "@/components/search-bar"
import { StorageStats } from "@/components/storage-stats"
import { Navigation } from "@/components/navigation"
import { useAppStore } from "@/lib/store"
import type { FileItem } from "@/lib/types"
import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

export default function StarredPage() {
  const { isAuthenticated, files } = useAppStore()
  const [starredFiles, setStarredFiles] = useState<FileItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setStarredFiles(files.filter((file) => file.starred))

    // Add a small delay to ensure smooth transition
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 300)
    return () => clearTimeout(timer)
  }, [files])

  // Show loading state instead of redirecting immediately
  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Loading starred files...</p>
        </div>
      </div>
    )
  }

  // Redirect to login if not authenticated after loading
  if (!isAuthenticated) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Navigation />

      <div className="flex-1 flex flex-col">
        <header className="border-b p-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold">Starred Files</h1>
            <SearchBar />
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-3">
                <Card className="p-6">
                  <div className="flex justify-between items-center mb-6">
                    <h2 className="text-xl font-semibold">Starred Files</h2>
                  </div>

                  {starredFiles.length > 0 ? (
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                      {/* This would be a simplified version of the file grid component */}
                      {/* For brevity, we're not duplicating all that code here */}
                      <div className="text-center py-12">
                        <p>Showing {starredFiles.length} starred files</p>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-12">
                      <h3 className="text-lg font-medium">No starred files</h3>
                      <p className="text-sm text-muted-foreground mt-1">Star files to add them to this list</p>
                    </div>
                  )}
                </Card>
              </div>
              <div className="lg:col-span-1">
                <StorageStats />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}

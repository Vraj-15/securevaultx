"use client"
import { useState, useEffect } from "react"
import { redirect } from "next/navigation"
import { FileUpload } from "@/components/file-upload"
import { FileGrid } from "@/components/file-grid"
import { SearchBar } from "@/components/search-bar"
import { StorageStats } from "@/components/storage-stats"
import { Navigation } from "@/components/navigation"
import { useAppStore } from "@/lib/store"
import { Loader2 } from "lucide-react"

export default function FilesPage() {
  const { isAuthenticated } = useAppStore()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Add a small delay to ensure smooth transition
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 300)
    return () => clearTimeout(timer)
  }, [])

  // Show loading state instead of redirecting immediately
  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-2">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
          <p className="text-sm text-muted-foreground">Loading your files...</p>
        </div>
      </div>
    )
  }

  // Redirect to login if not authenticated after loading
  if (!isAuthenticated) {
    redirect("/login")
  }

  return (
    <div className="flex min-h-screen bg-background">
      <Navigation />

      <div className="flex-1 flex flex-col">
        <header className="border-b p-4">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-bold">My Files</h1>
            <SearchBar />
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6">
          <div className="container mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-3">
                <FileUpload />
                <FileGrid />
              </div>
              <div className="lg:col-span-1">
                <StorageStats />
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  )
}
